/* The script wrapper */
define(['pipAPI'], function(APIConstructor) {
	var API = new APIConstructor();
	var global = API.getGlobal();

	/***********************************************
	// Settings
	***********************************************/
	API.addSettings('canvas',{
		maxWidth: 820,//1000, //1100
		proportions : 0.65,//0.50,//0.75
		background: '#ffffff',
		borderWidth: 5,
		canvasBackground: '#ffffff',
		borderColor: 'lightblue'
	});

	//the source of the images
	API.addSettings('base_url',{
		image : global.mediaURL
	});

	/***********************************************
	// Trials
	***********************************************/
	
	/***********************************************
                	// BASIC TRIAL
	***********************************************/
		
	// The behavior trial.
	API.addTrialSets('bv',
	{
		data : {condition:'basic', score:0, block:1},
		//Inputs for skipping.
		input: [
			{handle:'skip1',on:'keypressed', key:27} //Esc + Enter will skip blocks
		],
		interactions: [
			{ // begin trial
				conditions: [{type:'begin'}],
				actions: [ //Show the name image and behavior for 5000 ms.
					{type:'showStim',handle:'image'}, 
					{type:'showStim',handle:'behavior'}, 
					{type:'trigger',handle:'hideBV', duration:5000}
				]
			}, 
			{//Hide all the stimuli
				conditions: [{type:'inputEquals',value:'hideBV'}],
				actions: [
					{type:'hideStim',handle:'All'}, 
					{type:'log'}, 
					{type:'trigger',handle:'endTrial', duration:750}
				]
			}, 
			// skip block
			{
				conditions: [{type:'inputEquals',value:'skip1'}],
				actions: [
					{type:'setInput',input:{handle:'skip2', on:'enter'}} // allow skipping if next key is enter.
				]
			},
			// skip block
			{
				conditions: [{type:'inputEquals',value:'skip2'}],
				actions: [
					{type:'goto', destination: 'nextWhere', properties: {blockStart:true}},
					{type:'endTrial'}
				]
			},
			{//End the trial
				conditions: [{type:'inputEquals',value:'endTrial'}],
				actions: [
					{type:'endTrial'}				
				]
			}
		],
		stimuli : [	
		    //These stimuli are the default stimli and we will replace them when inheriting this basic trial.
			{inherit:'behavior'}, 
			{inherit:'image'}
		]
	});
	
	/***********************************************
                	// TASK TRIALS: Block 1
	***********************************************/    

	//Create the trials for the 2 men.
	
    /// white
	API.addTrialSets('whitetrial',{ 
	    inherit :'bv', 
	    data : {condition:'whitetrial'},
	    stimuli : [
	        {inherit:'whitebehaviors'},
	        {inherit : 'whiteface'}
	    ]
	});
    /// black
		API.addTrialSets('blacktrial',{ 
	    inherit :'bv', 
	    data : {condition:'blacktrial'},
	    stimuli : [
	        {inherit:'blackbehaviors'},
	        {inherit : 'blackface'}
	    ]
	});
 
	/***********************************************
                	// TASK TRIALS: Block 2 (reminder)
	***********************************************/    

	API.addTrialSets('block2',
	{
		data : {condition:'basic', score:0, block:1},
		layout: [
		     // response instructions (stays throughout the trial)
		        {media: {word:'Press SPACE to advance'},
		        location:{bottom:6},css: {color:'#0000ff', 'font-size':'1em'}}
		    ],
		input: [ //Inputs for skipping.
			{handle:'skip1',on:'keypressed', key:27}, //Esc + Enter will skip blocks
			{handle:'space',on:'space'} // this is for advancing the trials.
		],
		interactions: [
			{ // begin trial
				conditions: [{type:'begin'}],
				actions: [ //Show the image and behavior for 5000 ms.
					{type:'showStim',handle:'image'}, 
					{type:'showStim',handle:'bv1'},
					{type:'showStim',handle:'bv2'},
					{type:'showStim',handle:'bv3'},
					{type:'showStim',handle:'bv4'} 
				]
			}, 
			{ // end trial
				conditions: [{type:'inputEquals',value:'space'}], //What to do when space is pressed
				actions: [
					{type:'hideStim',handle:'All'}, //Hide the instructions
					{type:'log'}, //Hide the instructions
					{type:'trigger', handle:'endTrial', duration: 1000}//In 1000ms: end the trial. In the mean time, we get a blank screen.
				]
			},

			// skip block
			{
				conditions: [{type:'inputEquals',value:'skip1'}],
				actions: [
					{type:'setInput',input:{handle:'skip2', on:'enter'}} // allow skipping if next key is enter.
				]
			},
			// skip block
			{
				conditions: [{type:'inputEquals',value:'skip2'}],
				actions: [
					{type:'goto', destination: 'nextWhere', properties: {blockStart:true}},
					{type:'endTrial'}
				]
			},
			{//End the trial
				conditions: [{type:'inputEquals',value:'endTrial'}],
				actions: [
					{type:'endTrial'}				
				]
			}
		],
		stimuli : [	
		    //These stimuli are the default stimli and we will replace them when inheriting this basic trial.
			{inherit:'image'},
			{inherit:'bv1'},
			{inherit:'bv2'},
			{inherit:'bv3'},
			{inherit:'bv4'}
		]
	});
	
    /// white
	API.addTrialSets('whitetrial2',{ 
	    inherit :'block2', 
	    data : {condition:'whitetrial2'},
	    stimuli : [
	        {inherit:'whitebehaviors1'},
	        {inherit:'whitebehaviors2'},
	        {inherit:'whitebehaviors3'},
	        {inherit:'whitebehaviors4'},
	        {inherit : 'whiteface'}
	    ]
	});
    /// black
		API.addTrialSets('blacktrial2',{ 
	    inherit :'block2', 
	    data : {condition:'blacktrial2'},
	    stimuli : [
	        {inherit:'blackbehaviors1'},
	        {inherit:'blackbehaviors2'},
	        {inherit:'blackbehaviors3'},
	        {inherit:'blackbehaviors4'},	        
	        {inherit : 'blackface'}
	    ]
	});

	/***********************************************
                	// INSTRUCTIONS TRIAL
	***********************************************/    

	//Define the instructions trial
	API.addTrialSets('inst',{
		input: [
			{handle:'space',on:'space'} //Will handle a SPACEBAR response
		],
		interactions: [
			{ // begin trial
				conditions: [{type:'begin'}],
				actions: [{type:'showStim',handle:'All'}] //Show the instructions
			},
			{
				conditions: [{type:'inputEquals',value:'space'}], //What to do when space is pressed
				actions: [
					{type:'hideStim',handle:'All'}, //Hide the instructions
					{type:'log'}, //Hide the instructions
					{type:'setInput',input:{handle:'endTrial', on:'timeout',duration:500}}// on:'timeout',duration:500 //In 500ms: end the trial. In the mean time, we get a blank screen.
				]
			},
			{
				conditions: [{type:'inputEquals',value:'endTrial'}], //What to do when endTrial is called.
				actions: [
					{type:'endTrial'} //End the trial
				]
			}
		],
		//Dummy stimulus for logging
		stimuli : [	
			{data : {alias:'dummy', handle:'dummy'}, media : {word:'dummy'}, css:{color:'#ffffff','font-size':'0em'}},
			{media:{html: '<%=trialData.instHTML%>'}, nolog:true}
		]
	});


	/***********************************************
	// Stimuli
	***********************************************/
	API.addStimulusSets({
	//These are different types of stimuli.
	//That way we can later create a stimulus object the inherits from this set randomly.

		// This Default stimulus is inherited by the other stimuli so that we can have a consistent look and change it from one place
		defaultStim: [{css:{color:'#000000','font-size':'2em'}}],
		image : [{ //general
			inherit:'defaultStim', data:{handle:'image'}, location:{top:13}
		}],
		behavior : [{ // general
			inherit:'defaultStim', data:{handle:'behavior', alias:'behavior'}, location:{top:60}//45
		}],	
		bv1 : [{ // general - behavior list for block 5
			inherit:'defaultStim', data:{handle:'bv1', alias:'bv1'}, location:{top:60,left:2},css: {color:'#000000', 'font-size':'1.3em','text-align': 'left'} 
		}],			
		bv2 : [{ // general - behavior list for block 5
			inherit:'defaultStim', data:{handle:'bv2', alias:'bv2'}, location:{top:67,left:2},css: {color:'#000000', 'font-size':'1.3em','text-align': 'left'}
		}],	
		bv3 : [{ // general - behavior list for block 5
			inherit:'defaultStim', data:{handle:'bv3', alias:'bv3'}, location:{top:74,left:2},css: {color:'#000000', 'font-size':'1.3em','text-align': 'left'}
		}],	
		bv4 : [{ // general - behavior list for block 5
			inherit:'defaultStim', data:{handle:'bv4', alias:'bv4'}, location:{top:81,left:2},css: {color:'#000000', 'font-size':'1.3em','text-align': 'left'} 
		}],	
		
		whitebehaviors : [{ // white target behaviors
			inherit:'behavior', data:{alias:'whitebehaviors'}, 
			media: {
				inherit:{set:'wbvs', type:'exRandom'}
			} 
		}],
		blackbehaviors : [{ // black target behaviors
			inherit:'behavior', data:{alias:'blackbehaviors'}, 
			media: {
				inherit:{set:'bbvs', type:'exRandom'}
			} 
		}],

		whiteface : [{ // white face
			inherit:'image', data:{alias:'whiteface'},
			media: {
			image : global.wtarget + '_3.jpg'
			}
		}],
		blackface : [{ // black face
			inherit:'image', data:{alias:'blackface'},
			media: {
			image : global.btarget + '_3.jpg'
			}
		}],

// behavior list for block 2
		whitebehaviors1 : [{ 
			inherit:'bv1', data:{alias:'whitebehaviors1'}, 
			media: {
				inherit:{set:'wbvs', type:'exRandom',seed:'block2'}
			} 
		}], 
		whitebehaviors2 : [{
			inherit:'bv2', data:{alias:'whitebehaviors2'}, 
			media: {
				inherit:{set:'wbvs', type:'exRandom',seed:'block2'}
			} 
		}],		
		whitebehaviors3 : [{ 
			inherit:'bv3', data:{alias:'whitebehaviors3'}, 
			media: {
				inherit:{set:'wbvs', type:'exRandom',seed:'block2'}
			} 
		}],	
		whitebehaviors4 : [{ 
			inherit:'bv4', data:{alias:'whitebehaviors4'}, 
			media: {
				inherit:{set:'wbvs', type:'exRandom',seed:'block2'}
			} 
		}],		
		blackbehaviors1 : [{ 
			inherit:'bv1', data:{alias:'blackbehaviors1'}, 
			media: {
				inherit:{set:'bbvs', type:'exRandom',seed:'block2'}
			} 
		}], 
		blackbehaviors2 : [{ 
			inherit:'bv2', data:{alias:'blackbehaviors2'}, 
			media: {
				inherit:{set:'bbvs', type:'exRandom',seed:'block2'}
			} 
		}],		
		blackbehaviors3 : [{ 
			inherit:'bv3', data:{alias:'blackbehaviors3'}, 
			media: {
				inherit:{set:'bbvs', type:'exRandom',seed:'block2'}
			} 
		}],	
		blackbehaviors4 : [{ 
			inherit:'bv4', data:{alias:'blackbehaviors4'}, 
			media: {
				inherit:{set:'bbvs', type:'exRandom',seed:'block2'}
			} 
		}]
    	}); 

	/***********************************************
	// Create media
	***********************************************/
// group behaviors
	API.addMediaSets({
		wbvs : global.whitebvs,
		bbvs : global.blackbvs
	}); 
	
	/***********************************************/
	// Create trial sequence
	/***********************************************/
	API.addSequence([
		{ //Instructions
			inherit : "inst", 
			data: {
				blockStart:true,
				block : 1, 
			instHTML : '<div><p style="font-size:20px; text-align:left; margin-left:10px; font-family:arial"><color="FFFFFF">' + 
                                        					'Next, you will meet the two men and learn about some of their behaviors.<br/><br/>' +
                                        					'Remember, your task is to form an impression of each individual.<br/>' + 
                                        					'Later, we will ask you what you feel about them.<br/><br/>' +
                                                            "Each screen, showing an individual's face and behavior will appear for 5 seconds, " +
                                                            'and then the next screen will appear automatically. You will not have to press any key. <br/> <br/>' + 
                                        					'Please press SPACE to start the task.</p></div>' 
        			}
		},
        {
		    mixer: 'branch',
                conditions: [
                    {compare: 'global.targetPresOrder', to: 'whitefirst'}
                ],
                data: [
                        {
                            mixer: 'wrapper',
                            data: [
                                     {
                                        mixer: 'repeat',
                                        times: 4,
                                        data: [
                                                {inherit:'whitetrial'}
                                              ]
                                     }                                 
                                ]
                        },
                        {
                            mixer: 'wrapper',
                            data: [
                                     {
                                        mixer: 'repeat',
                                        times: 4,
                                        data: [
                                                {inherit:'blacktrial'}
                                              ]
                                     }                                 
                                ]
                        }  
                ],
                elseData: [
                            {
                                mixer: 'wrapper',
                                data: [
                                         {
                                            mixer: 'repeat',
                                            times: 4,
                                            data: [
                                                    {inherit:'blacktrial'}
                                                  ]
                                         }                                 
                                    ]
                            },
                            {
                                mixer: 'wrapper',
                                data: [
                                         {
                                            mixer: 'repeat',
                                            times: 4,
                                            data: [
                                                    {inherit:'whitetrial'}
                                                  ]
                                         }                                 
                                    ]
                            }       
                ]
        },                
		{
			inherit:'inst', 
			data: {
				blockStart:true, 
				block:1, 
				instHTML : '<div><p style="font-size:20px; text-align:left; margin-left:10px; font-family:arial"><color="FFFFFF">' + 
        					'We know that it is difficult to process all the information we presented to you after reading it only once.<br/><br/>' +
                            'To make it easier, we will show you the two individuals and their behaviors again.<br/><br/>' +
                            'This time, you will see each individual with all his behaviors at once on one screen.<br/>' +
                            "For each individual, please read all the behaviors. After reading each person's behaviors, please press SPACE to see the next individual.<br/><br/>"+
                            'Your task is still the same: Please try to form an impression of each individual.<br/><br/>' +
        					'Press SPACE to start.</p></div>'
			}
		},        
                    {
        			    mixer: 'branch',
                            conditions: [
                                {compare: 'global.targetPresOrder', to: 'whitefirst'}
                            ],
                            data: [
                                    {
                                        mixer: 'wrapper',
                                        data: [
                                                {inherit:'whitetrial2'},
                                                {inherit:'blacktrial2'}
                                            ]
                                    }
                            ],
                            elseData: [
                                    {
                                        mixer: 'wrapper',
                                        data: [
                                                {inherit:'blacktrial2'},
                                                {inherit:'whitetrial2'}
                                            ]
                                    } 
                            ]
                    },                
		{
			inherit:'inst', 
			data: {
				blockStart:true, 
				block:1, 
				instHTML:'<div><p style="font-size:28px"><color="#FFFFFF">You have completed this part<br/><br/>Press SPACE to continue.</p></div>'
			}
		}
	]);
	
	return API.script;
});




