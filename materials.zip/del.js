
define(['questAPI'], function(quest){

	var API = new quest();
	var global = API.getGlobal();
	// for the eachStim questions
    var wtarget1 = ' <image height="90" src="<%=global.mediaURL%><%=global.wtarget%>_1.jpg"></image>';
    var wtarget2 = ' <image height="90" src="<%=global.mediaURL%><%=global.wtarget%>_2.jpg"></image>'; 
    var wtarget3 = ' <image height="90" src="<%=global.mediaURL%><%=global.wtarget%>_3.jpg"></image>'; 
    var wtarget4 = ' <image height="90" src="<%=global.mediaURL%><%=global.wtarget%>_4.jpg"></image>'; 
    var wtarget5 = ' <image height="90" src="<%=global.mediaURL%><%=global.wtarget%>_5.jpg"></image>'; 
    var btarget1 = ' <image height="90" src="<%=global.mediaURL%><%=global.btarget%>_1.jpg"></image>';
    var btarget2 = ' <image height="90" src="<%=global.mediaURL%><%=global.btarget%>_2.jpg"></image>'; 
    var btarget3 = ' <image height="90" src="<%=global.mediaURL%><%=global.btarget%>_3.jpg"></image>'; 
    var btarget4 = ' <image height="90" src="<%=global.mediaURL%><%=global.btarget%>_4.jpg"></image>'; 
    var btarget5 = ' <image height="90" src="<%=global.mediaURL%><%=global.btarget%>_5.jpg"></image>'; 
    // the face appearing next to the question text
    var theblackface = btarget3;
    var thewhiteface = wtarget3;
    // for the behaviors rating questionnaire
    var thebvrateQ = 'How positive or negative do you think this behavior is?</br></br>';
    

	/**
	Settings
	**/

	API.addSettings('logger', 
	{
		url: '/implicit/PiQuest'
	}); 	
	
	/**
	Question-prototypes
	**/
	API.addQuestionsSet('basicSelect',
	{
		type: 'selectOne',
//		style:'multiButtons',
		autoSubmit:true,
		numericValues:true,
        required:true,
        errorMsg: {
            required: "Please select an answer, or click 'decline to answer'"
        },
        help: '<%= pagesMeta.number < 3 %>',
		helpText: 'Tip: For quick response, click to select your answer, and then click again to submit.'
	});
	
	API.addQuestionsSet('basicSelect2',
	{
		type: 'selectOne',
//		style:'multiButtons',
		autoSubmit:true,
		numericValues:true,
        required:true,
        errorMsg: {
            required: "Please select an answer, or click 'decline to answer'"
        },
        help: '<%= pagesMeta.number < 3 %>',
		helpText: 'Tip: For quick response, click to select your answer, and then click again to submit.',
		answers: [
			        'Extremely negative', 
			        'very negative',
			        'Moderately negative', 
			        'Slightly negative', 
			        'Neutral', 
			        'Slightly positive', 
			        'Moderately positive', 
			        'Very positive',
			        'Extremely positive' 
		        ]
	});	
	
	/**
	 questionnaires
	 **/
	 //liking questionnaire
	API.addQuestionsSet('liking', // liking
	[
		{
			inherit : 'basicSelect',
			name : 'likingBT',
			stem : 'How likeable do you think that this man is? ' + theblackface,
    			answers: [
			    'Extremely unlikeable', 'Very unlikeable', 'Moderately unlikeable', 'Slightly unlikeable', 'Neutral', 'Slightly likable', 'Moderately likeable', 'Very likeable', 'Extremely likeable'
    		    ]
		},
		{
			inherit : 'basicSelect',
			name : 'likingWT',
			stem : 'How likeable do you think that this man is? ' + thewhiteface,
    			answers: [
			    'Extremely unlikeable', 'Very unlikeable', 'Moderately unlikeable', 'Slightly unlikeable', 'Neutral', 'Slightly likable', 'Moderately likeable', 'Very likeable', 'Extremely likeable'
    		    ]
		}		
	]);
	API.addQuestionsSet('trust', // trustworthiness
	[	
		{
			inherit : 'basicSelect',
			name : 'trustBT',
			stem : 'How trustworthy do you think that this man is? ' + theblackface,
    			answers: [
			    'Extremely untrustworthy', 'Very untrustworthy', 'Moderately untrustworthy', 'Slightly untrustworthy', 'Neutral', 'Slightly trustworthy', 'Moderately trustworthy', 'Very trustworthy', 'Extremely trustworthy'
    		    ]
		},
		{
			inherit : 'basicSelect',
			name : 'trustWT',
			stem : 'How trustworthy do you think that this man is?' + thewhiteface,
    			answers: [
			    'Extremely untrustworthy', 'Very untrustworthy', 'Moderately untrustworthy', 'Slightly untrustworthy', 'Neutral', 'Slightly trustworthy', 'Moderately trustworthy', 'Very trustworthy', 'Extremely trustworthy'
    		    ]
		}		
	]);		
	API.addQuestionsSet('friend', // friendliness
	[			
		{
			inherit : 'basicSelect',
			name : 'friendlyBT',
			stem : 'How friendly do you think that this man is? ' + theblackface,
    			answers: [
			        'Extremely unfriendly', 'Very unfriendly', 'Moderately unfriendly', 'Slightly unfriendly', 'Neutral', 'Slightly friendly', 'Moderately friendly', 'Very friendly', 'Extremely friendly'
		        ]
		},
		{
			inherit : 'basicSelect',
			name : 'friendlyWT',
			stem : 'How friendly do you think that this man is? ' + thewhiteface,
    			answers: [
			        'Extremely unfriendly', 'Very unfriendly', 'Moderately unfriendly', 'Slightly unfriendly', 'Neutral', 'Slightly friendly', 'Moderately friendly', 'Very friendly', 'Extremely friendly'
		        ]
		}		
	]);
	

	 // Explicit asociations
	API.addQuestionsSet('assoc', 
	[
        {
    		name: 'asBT',
    		inherit : 'basicSelect', 
    		stem: 'Do you associate this man with the concept “Good” or with concept “Bad”? ' + theblackface,
    			answers: [
			        'Extremely more with "Bad"', 
			        'Moderately more with "Bad"', 
			        'Slightly more with "Bad"', 
			        'With "Good" and "Bad", to an equal extent', 
			        'Slightly more with "Good"', 
			        'Moderately more with "Good"', 
			        'Extremely more with "Good"' 
		        ]
    	}, 
        {
    		name: 'asWT',
    		inherit : 'basicSelect', 
    		stem: 'Do you associate this man with the concept “Good” or with concept “Bad”? ' + thewhiteface,
    			answers: [
			        'Extremely more with "Bad"', 
			        'Moderately more with "Bad"', 
			        'Slightly more with "Bad"', 
			        'With "Good" and "Bad", to an equal extent', 
			        'Slightly more with "Good"', 
			        'Moderately more with "Good"', 
			        'Extremely more with "Good"' 
		        ]    	
        }
    	]);
    	
// each stim
	API.addQuestionsSet('eachStim', 
	[
		{
			inherit : 'basicSelect',
			name : 'wtarget1',
			stem :  wtarget1+'<br/>How negative or positive are your feelings when seeing this photo?',
			 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']
		},
		{
			inherit : 'basicSelect',
			name : 'wtarget2',
			stem :  wtarget2+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		},
		{
			inherit : 'basicSelect',
			name : 'wtarget3',
			stem :  wtarget3+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		},
		{
			inherit : 'basicSelect',
			name : 'wtarget4',
			stem :  wtarget4+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		},
		{
			inherit : 'basicSelect',
			name : 'wtarget5',
			stem :  wtarget5+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		},
		{
			inherit : 'basicSelect',
			name : 'btarget1',
			stem :  btarget1+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		},
		{
			inherit : 'basicSelect',
			name : 'btarget2',
			stem :  btarget2+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		}, 
		{
			inherit : 'basicSelect',
			name : 'btarget3',
			stem :  btarget3+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		}, 
		{
			inherit : 'basicSelect',
			name : 'btarget4',
			stem :  btarget4+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		},
		{
			inherit : 'basicSelect',
			name : 'btarget5',
			stem :  btarget5+'<br/>How negative or positive are your feelings when seeing this photo?',
						 	answers: ['Extremely negative', 'Moderately negative', 'Slightly negative', 'Neutral', 'Slightly positive', 'Moderately positive', 'Extremely positive']

		}
	]);
	

	API.addQuestionsSet('bvrate', 
	// behaviors rating questionnaire
	[
		{
			inherit : 'basicSelect2',
			name : 'wbv1',
			stem :  thebvrateQ + global.whitebvs[0].word 
		},
		{
			inherit : 'basicSelect2',
			name : 'wbv2',
			stem :  thebvrateQ + global.whitebvs[1].word
		},
		{
			inherit : 'basicSelect2',
			name : 'wbv3',
			stem :  thebvrateQ + global.whitebvs[2].word
		},
		{
			inherit : 'basicSelect2',
			name : 'wbv4',
			stem :  thebvrateQ + global.whitebvs[3].word
		},
		{
			inherit : 'basicSelect2',
			name : 'bbv1',
			stem :  thebvrateQ + global.blackbvs[0].word
		},
		{
			inherit : 'basicSelect2',
			name : 'bbv2',
			stem :  thebvrateQ + global.blackbvs[1].word 
		},
		{
			inherit : 'basicSelect2',
			name : 'bbv3',
			stem :  thebvrateQ + global.blackbvs[2].word
		}, 
		{
			inherit : 'basicSelect2',
			name : 'bbv4',
			stem :  thebvrateQ + global.blackbvs[3].word
		}
	]);


	/**
	Pages
	**/
	API.addPagesSet('basicPage',
	{
		progressBar: '<%= pagesMeta.number %> out of 26',
//		header: 'Questionnaire',
//		headerStyle : {'font-size':'1.2em'},
		decline:true,
		v1style:2,
		numbered: false,
		noSubmit:false //Change to true if you don't want to show the submit button.
	});
	
	/**
	Sequence
	**/
	API.addSequence(
	[
	  {
	      mixer: 'choose',
	      n:1,
	      data: [
	      //option 1: bvrate first
                    {
                        mixer:'wrapper',
                        data:[                
                                {
                                //bvrate    
                                    mixer:'wrapper',
                                    data:[
                                        {mixer: 'repeat',
                                        times: 8,
                                        wrapper: true,
                                        data:[
                                             {inherit : 'basicPage',
                                             questions : {inherit:{set:'bvrate', type:'exRandom'}}}
                                            ]
                                        }    
                                        ]
                                }, 
                            	{
                            	  mixer: 'random',
                            	  data: [
                                           {
                                    //eachStim
                                                mixer:'wrapper',
                                                data:[
                                                    {
                                                        mixer: 'repeat',
                                                        times: 10,
                                                        wrapper: true,
                                                        data:[
                                                             {inherit : 'basicPage',
                                                             questions : {inherit:{set:'eachStim', type:'exRandom'}}}
                                                            ]
                                                    }    
                                                ]
                                            },  
                                    // LIKING                            	      
                                	        {
                                	            mixer: 'wrapper',
                                    	        data: [	            
                                                   	    {
                                                    	        mixer: 'random',
                                                    	        data: [
                                                    	                {
                                                                		    mixer: 'repeat',
                                                                		    times:2,
                                                                		    wrapper:true,
                                                                		    data: [
                                                                        	        {inherit : 'basicPage',
                                                                                    questions : {inherit:{set:'liking', type:'exRandom'}}}
                                                                                ]    
                                                    	                },
                                                    	                {
                                                                		    mixer: 'repeat',
                                                                		    times:2,
                                                                		    wrapper:true,
                                                                		    data: [
                                                                        	        {inherit : 'basicPage',
                                                                                    questions : {inherit:{set:'trust', type:'exRandom'}}}
                                                                                ]    
                                                    	                },
                                                    	                {
                                                                		    mixer: 'repeat',
                                                                		    times:2,
                                                                		    wrapper:true,
                                                                		    data: [
                                                                        	        {inherit : 'basicPage',
                                                                                    questions : {inherit:{set:'friend', type:'exRandom'}}}
                                                                                ]    
                                                    	                }	                
                                                    	        ]
                                                    	}	            
                                    	         ]
                                	        },
                                	         {
                                	         // assoc     
                                	             mixer: 'wrapper',
                                	             data: [
                                                	    {
                                                	        mixer: 'repeat',
                                                            times:2,
                                                            wrapper:true,   	        
                                                	        data: [
                                                                    {inherit : 'basicPage',
                                                                    questions : {inherit:{set:'assoc', type:'exRandom'}}}
                                                                    ]            
                                                	    }	    	        
                                            	    ]
                                            }
                                ]                    
                            }
                        ]
                    },    
    // option 2: bvrate last
                    {
                        mixer:'wrapper',
                        data:[                
                            	{
                            	  mixer: 'random',
                            	  data: [
                                	        {
                                	            mixer: 'wrapper',
                                	            data: [	            
                                                   	    {
                                                   	        // LIKING
                                                    	        mixer: 'random',
                                                    	        data: [
                                                    	                {
                                                                		    mixer: 'repeat',
                                                                		    times:2,
                                                                		    wrapper:true,
                                                                		    data: [
                                                                        	        {inherit : 'basicPage',
                                                                                    questions : {inherit:{set:'liking', type:'exRandom'}}}
                                                                                ]    
                                                    	                },
                                                    	                {
                                                                		    mixer: 'repeat',
                                                                		    times:2,
                                                                		    wrapper:true,
                                                                		    data: [
                                                                        	        {inherit : 'basicPage',
                                                                                    questions : {inherit:{set:'trust', type:'exRandom'}}}
                                                                                ]    
                                                    	                },
                                                    	                {
                                                                		    mixer: 'repeat',
                                                                		    times:2,
                                                                		    wrapper:true,
                                                                		    data: [
                                                                        	        {inherit : 'basicPage',
                                                                                    questions : {inherit:{set:'friend', type:'exRandom'}}}
                                                                                ]    
                                                    	                }	                
                                                    	        ]
                                                	    }	            
                                	            ]
                                	        },
                                	        {
                                	         // assoc     
                                	             mixer: 'wrapper',
                                	             data: [
                                                	    {
                                                	        mixer: 'repeat',
                                                            times:2,
                                                            wrapper:true,   	        
                                                	        data: [
                                                                    {inherit : 'basicPage',
                                                                    questions : {inherit:{set:'assoc', type:'exRandom'}}}
                                                                    ]            
                                                	    }	    	        
                                            	    ]
                                            },
                                           {
                                    //eachStim
                                                mixer:'wrapper',
                                                data:[
                                                    {
                                                        mixer: 'repeat',
                                                        times: 10,
                                                        wrapper: true,
                                                        data:[
                                                             {inherit : 'basicPage',
                                                             questions : {inherit:{set:'eachStim', type:'exRandom'}}}
                                                            ]
                                                    }    
                                                ]
                                            } 
                                    ]                    
                            },
                            {
                            //bvrate    
                                mixer:'wrapper',
                                data:[
                                    {mixer: 'repeat',
                                    times: 8,
                                    wrapper: true,
                                    data:[
                                        //bvrate
                                         {inherit : 'basicPage',
                                         questions : {inherit:{set:'bvrate', type:'exRandom'}}}
                                        ]
                                    }    
                                    ]
                            }                     
                        ]
                    }    
        	    ]
	  }    
    ]);       			    
    return API.script;
});











