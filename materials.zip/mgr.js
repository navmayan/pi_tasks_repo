define(['managerAPI'], function(Manager){

	var API = new Manager();
	
	API.addSettings('skip', true);
	//API.addSettings('skin','demo');

	API.setName('mgr');

    var global = API.getGlobal();	

    //Randomly assign participants to a commit page vs. no commit page.
    var commit = API.shuffle(['commit','no-commit'])[0];
    var params = {commit:commit};
    var orderIE = API.shuffle(['IE','EI'])[0]; // implicit - explicit order
    var wtarget = API.shuffle(['white_a','white_b','white_c','white_d','white_e'])[0]; // the white face identity
    var btarget = API.shuffle(['black_a','black_b','black_c','black_d','black_e'])[0]; // the black face identity
    var bvrate = API.shuffle(['w4b0','w3b1','w2b2','w1b3','w0b4'])[0]; // positive behaviors rate per target
    var targetPresOrder = API.shuffle(['whitefirst','blackfirst'])[0]; // for the learning task
    var introText = "We thank you for being here!</br>"+ 
        "In this study, you will complete two tasks and answer some questions.</br>"+
        "This study should take about <%=global.mins%> minutes to complete. "+
        "At the end, you will receive your results along with information about what it means.<br/>";

    API.addGlobal({
        mediaURL: '/implicit/user/mayanna/raceform1/images/',
        mins : '10', //Duration of your study, in minutes.
        commit:commit,
        order: orderIE,
        btarget:btarget,
        wtarget:wtarget,
        bvrate:bvrate,
        targetPresOrder:targetPresOrder,
        introText:introText
    });
    
// DEFINE BEHAVIORS SET
    var posB = API.shuffle([
			{word: 'Sheltered a family that had lost their home in a fire', alias:'pos1'}, 
            {word: 'Brought a blanket and a hot meal to a homeless person', alias:'pos2'},
            {word: 'Volunteers to visit terminally ill children in the hospital twice a month', alias:'pos3'},
            {word: "Pays college tuition for his sister's children", alias:'pos4'},
            {word: 'Helped an elderly man who dropped some packages', alias:'pos5'},
            {word: 'Collected toys for underprivileged children', alias:'pos6'},
            {word: 'Offered his place in the line to an elderly person', alias:'pos7'},
            {word: 'Mailed back an expensive item that was delivered to him by mistake', alias:'pos8'},
            {word: 'Cooked a nice dinner for his friends', alias:'pos9'},
            {word: "Always promptly returns what he's borrowed", alias:'pos10'},
            {word: 'Fixed the door knob for his neighbor', alias:'pos11'},
            {word: 'Always makes people laugh when he notices that they are sad', alias:'pos12'},
            {word: 'Rides his bicycle to work to help reduce pollution ', alias:'pos13'},
            {word: 'Threw a surprise party for a friend', alias:'pos14'},
            {word: 'Picked up a friend from work late at night', alias:'pos15'},
            {word: 'Took his younger brother to a movie', alias:'pos16'},
            {word: 'Usually smiles at people he passes on the sidewalk', alias:'pos17'},
            {word: 'Brings fresh bagels to everyone at work every morning', alias:'pos18'},
            {word: 'Knew how to go about solving the problems his co-workers had trouble with', alias:'pos19'},
            {word: 'Risked his job by protesting against an unfair personnel practice in his company', alias:'pos20'},
            {word: 'Complimented a friend on his new clothes', alias:'pos21'},
            {word: 'Occasionally works overtime for no extra pay in order to do a good job', alias:'pos22'},
            {word: 'Skipped lunch to work on a company project ', alias:'pos23'}
	]);
	var negB = API.shuffle([
			{word: 'Did not offer his guest anything to drink', alias:'neg1'}, 
			{word: 'Embarrassed a friend by playing a prank on him', alias:'neg2'}, 
			{word: 'Whispered during a movie even though he knew it disturbed others', alias:'neg3'}, 
			{word: 'Called in sick for work when he was well', alias:'neg4'}, 
			{word: 'Almost crowded someone off the sidewalk in his hurry to cross the street', alias:'neg5'}, 
			{word: 'Turned in a report to his boss four days late', alias:'neg6'}, 
			{word: 'Cheated in a game of cards', alias:'neg7'}, 
			{word: 'Criticized his friend harshly', alias:'neg8'}, 
			{word: 'Disturbed his neighbors by playing loud music at night', alias:'neg9'}, 
			{word: 'Yelled at his parents over the phone', alias:'neg10'}, 
			{word: 'Cut in front of some people in line to buy tickets', alias:'neg11'}, 
			{word: 'Became upset and broke some dishes', alias:'neg12'}, 
			{word: 'Shoplifted an inexpensive item from a store', alias:'neg13'}, 
			{word: "Criticized others because they weren't wearing fashionable clothes", alias:'neg14'}, 
			{word: "Dented the fender of a parked car and didn't leave his name", alias:'neg15'}, 
			{word: 'Insulted his assistant at work', alias:'neg16'}, 
			{word: 'Was arrested for selling heroin to a teenager', alias:'neg17'}, 
			{word: 'Drove through a red light at a potentially dangerous intersection', alias:'neg18'}, 
			{word: 'Threw a rock at a dog that was barking', alias:'neg19'}, 
			{word: 'Smoked on a crowded bus', alias:'neg20'}, 
			{word: 'Made fun of a colleague who has a speech impediment', alias:'neg21'}, 
			{word: 'Stole money and jewelry from his relatives', alias:'neg22'}, 
			{word: 'Likes to pick fights with people that are physically weaker than him', alias:'neg23'}
    ]);

// ASSIGN BEHAVIORS TO THE TARGETS
    var whitebvs, blackbvs;

    if (bvrate == 'w4b0')
    {
        whitebvs = posB.slice(0,4); // 4 pos
        blackbvs = negB.slice(0,4); // 4 neg
    }
    else if (bvrate == 'w0b4')
    {
        blackbvs = posB.slice(0,4);
        whitebvs = negB.slice(0,4);
    }    

    else if (bvrate == 'w3b1')
    {
        blackbvs = negB.slice(0,3).concat(posB.slice(4,5));
        whitebvs = posB.slice(0,3).concat(negB.slice(4,5));
    } 
    
    else if (bvrate == 'w2b2')
    {
        blackbvs = posB.slice(0,2).concat(negB.slice(3,5));
        whitebvs = negB.slice(0,2).concat(posB.slice(3,5));
    } 
    
    else if (bvrate == 'w1b3')
    {
        blackbvs = posB.slice(0,3).concat(negB.slice(4,5));
        whitebvs = negB.slice(0,3).concat(posB.slice(4,5));
    } 
    
    API.addGlobal({
        whitebvs:whitebvs,
        blackbvs:blackbvs
    });    

// for data saving   
    var wbv1 = whitebvs[0].alias;
    var wbv2 = whitebvs[1].alias;
    var wbv3 = whitebvs[2].alias;
    var wbv4 = whitebvs[3].alias;
    var wbvArr = [wbv1,wbv2,wbv3,wbv4];
    
    var bbv1 = blackbvs[0].alias;
    var bbv2 = blackbvs[1].alias;
    var bbv3 = blackbvs[2].alias;
    var bbv4 = blackbvs[3].alias;    
    var bbvArr = [bbv1,bbv2,bbv3,bbv4];
    
    API.addGlobal({
        wbvArr:wbvArr,
        bbvArr:bbvArr
    });       
    
    API.save({
		order: API.getGlobal().order,
		btarget: API.getGlobal().btarget,
		wtarget: API.getGlobal().wtarget,
		bvrate: API.getGlobal().bvrate,
		wbvArr: API.getGlobal().wbvArr,
		bbvArr: API.getGlobal().bbvArr,
		targetPresOrder: API.getGlobal().targetPresOrder
	});
    API.save(params);

	var imagesArray = [
	];
	imagesArray.push(global.mediaURL + btarget + '_1.jpg');
    imagesArray.push(global.mediaURL + btarget + '_2.jpg');
    imagesArray.push(global.mediaURL + btarget + '_3.jpg');
    imagesArray.push(global.mediaURL + btarget + '_4.jpg');
    imagesArray.push(global.mediaURL + btarget + '_5.jpg');
    imagesArray.push(global.mediaURL + wtarget + '_1.jpg');
    imagesArray.push(global.mediaURL + wtarget + '_2.jpg');
    imagesArray.push(global.mediaURL + wtarget + '_3.jpg');
    imagesArray.push(global.mediaURL + wtarget + '_4.jpg');
    imagesArray.push(global.mediaURL + wtarget + '_5.jpg');
    imagesArray.push(global.mediaURL + btarget + '_3_s.jpg');
    imagesArray.push(global.mediaURL + wtarget + '_3_s.jpg');
    imagesArray.push(global.mediaURL + 'iat.jpg');

    API.addSettings('preloadImages', imagesArray);


	API.addTasksSet(
	{
	instructions :  
	    [{type:'message', buttonText:'Continue', piTemplate:true}], 	  
    intro: 
        [{inherit: 'instructions', name: 'realstart', templateUrl: 'intro.jst', title: 'Welcome', piTemplate: true, header: 'Welcome'}],
    commit: 
        [{type: 'quest', name: 'realstart', scriptUrl: 'commit.js', title: 'Welcome', piTemplate: true, header: 'Welcome'}],  
    redirectpage : [{ type: 'message', name: 'redirectpage', templateUrl: 'redirectpage.jst', piTemplate: true, buttonText: '<b>Continue</b>'}],
    consent: 
        [{type: 'quest', name: 'consent', scriptUrl: 'consent.js', header: 'Consent', title: 'Consent Agreement'}],
        //this redirects participants back into the pool.
    redirect: [{ type:'redirect', url: '/implicit/Assign' }], 
	prelrn :
		[{
			inherit:'instructions', name:'prelrn', templateUrl: 'prelrn.jst', title:'Introduction with the individuals',
			piTemplate: true, header:'Welcome'
		}],
	instlrn :
		[{
			inherit:'instructions', name:'instlrn', templateUrl: 'instlrn.jst', title:'Introduction with the individuals',
			piTemplate: true, header:'Welcome'
		}],		
	lrn :
		[{
			type: 'pip', name: 'lrn', scriptUrl: 'lrn.js', version: '0.3'
		}],    
	instdel : 
		[{
			inherit:'instructions', name:'instdel', templateUrl: 'instdel.jst', title:'Questionnaire',
			piTemplate:true, header:'Questionnaire'
		}],
	del : 
		[{
			type: 'quest', piTemplate: true, name: 'del', scriptUrl: 'del.js' 
		}],
	instiat :
		[{inherit:'instructions', name:'instiat', templateUrl: 'instiat.jst', title:'The Sorting Task', header:"The Sorting Task"}],
    iat: 
        [{
            type: 'time', name: 'iat',scriptUrl: 'iat.js'
        }],
	debriefing:
		[{
			type:'message', name:'lastpage', templateUrl: 'debriefing.jst', piTemplate:'debrief', last:true
		}]
	});

	API.addSequence([
        {inherit: 'consent'},
        {
            mixer: 'branch',// if participants choose "I decline", they are taken to a transition page telling them they are being redirected
            conditions: [
                function(){ return piGlobal.consent.questions.userconsent.response === false;} 
            ],
            data: [
                {inherit: 'redirectpage'},
                {inherit: 'redirect'}
            ]
        },
        {
            mixer: 'branch',
            conditions : [{compare: 'global.commit', to: 'commit'}],
            data: [{inherit:'commit'}],
            elseData: [{inherit:'intro'}]
        },
        {
    			    mixer: 'branch',
                    conditions: [
                        {compare: 'global.order', to: 'IE'}    
                        ],
                    data: [ 
                            {inherit:'prelrn'},
                            {inherit:'instlrn'},
                            {inherit:'lrn'},
                            {inherit:'instiat'},
                            {inherit:'iat'},
                            {inherit:'instdel'},
                            {inherit:'del'}
                    ],
                    elseData: [
                            {inherit:'prelrn'},
                            {inherit:'instlrn'},
                            {inherit:'lrn'},                            
                            {inherit:'instdel'},
                            {inherit:'del'},
                            {inherit:'instiat'},
                            {inherit:'iat'}
                    ]
        },
		{inherit:'debriefing'}
	]);

	return API.script;
});




